<?php ob_start();
include $_SERVER["DOCUMENT_ROOT"]."/inc/top.php";

if($_SESSION['UID']){
    $user_where = " and c.userid='".$_SESSION['UID']."'";
}else{
    $user_where = " and c.ssid='".session_id()."'";
}


$query = "select *, p.pid, c.cnt
                    from cart c
                    join products p on c.pid=p.pid where 1=1 ".$user_where;
$result = $mysqli->query($query) or die("query error => ".$mysqli->error);
while($rs = $result->fetch_object()){
    $rsc[]=$rs;
}

?>
    <div class="product-big-title-area">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="product-bit-title text-center">
                        <h2>Shopping Cart</h2>
                    </div>
                </div>
            </div>
        </div>
    </div> <!-- End Page title area -->
   
   
    <div class="single-product-area">
        <div class="zigzag-bottom"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-4" style="width: 20%;"> <!-- 너비를 조정하려는 부분 -->
                    <div class="single-sidebar">
                        <h2 class="sidebar-title">Search Products</h2>
                        <form action="#">
                            <input type="text" placeholder="Search products...">
                            <input type="submit" value="Search">
                        </form>
                    </div>
                   
                    <div class="single-sidebar">
                        <h2 class="sidebar-title">Products</h2>
                        <div class="thubmnail-recent">
                            <img src="img/product-thumb-1.jpg" class="recent-thumb" alt="">
                            <h2><a href="single-product.html">Sony Playstation</a></h2>
                            <div class="product-sidebar-price">
                                <ins>300,000 Won</ins> <del>500,000 Won</del>
                            </div>                            
                        </div>                          
                    </div>
                   
                    <div class="single-sidebar">
                        <h2 class="sidebar-title">Recent Posts</h2>
                        <ul>
                            <li><a href="#">Sony Smart TV - 2024</a></li>
                        </ul>
                    </div>
                </div>
               
                <div class="col-md-8">
                    <div class="product-content-right" style="width: 120%;"> <!-- 너비를 조정하려는 부분 -->
                        <div class="woocommerce">
                            <form method="post" action="#">
                                <table cellspacing="0" class="shop_table cart">
                                    <thead>
                                        <tr>
                                            <th class="product-remove">&nbsp;</th>
                                            <th class="product-thumbnail">&nbsp;</th>
                                            <th class="product-name">Product</th>
                                            <th class="product-price">Price</th>
                                            <th class="product-quantity">Quantity</th>
                                            <th class="product-subtotal">Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!-- 제품 리스트 -->
                                        <?php
                                            $cart_total=0;
                                            foreach($rsc as $p){
                                        ?>
                                        <tr class="cart_item" id="cart_<?php echo $p->cartid;?>">
                                            <td class="product-remove">
                                                <a title="Remove this item" class="remove" id="<?php echo $p->cartid;?>" href="#">×</a>
                                            </td>

                                            <td class="product-thumbnail">
                                                <a href="/products.php?pid=<?php echo $p->pid;?>"><img width="145" height="145" alt="poster_1_up" class="shop_thumbnail" src="<?php echo $p->thumbnail;?>"></a>
                                            </td>

                                            <td class="product-name">
                                                <a href="/products.php?pid=<?php echo $p->pid;?>"><?php echo $p->name;?></a>
                                            </td>

                                            <td class="product-price">
                                                <span class="amount"><?php echo number_format($p->sale_price);?>원</span>
                                            </td>

                                            <td class="product-quantity">
                                                <div class="quantity buttons_added">
                                                    <input type="button" class="minus" id="<?php echo $p->cartid;?>" value="-">
                                                    <input type="text" id="qty_<?php echo $p->cartid;?>" size="4" class="input-text qty text" title="Qty" value="<?php echo $p->cnt;?>" readonly>
                                                    <input type="button" class="plus" id="<?php echo $p->cartid;?>" value="+">
                                                </div>
                                            </td>
                                            <input type="hidden" name="price" id="price_<?php echo $p->cartid;?>" value="<?php echo $p->sale_price;?>">
                                            <td class="product-subtotal">
                                                <span class="amount" id="amount_<?php echo $p->cartid;?>"><?php echo number_format($p->sale_price*$p->cnt);?>원</span>
                                            </td>
                                        </tr>
                                        <?php
                                            $cart_total = $cart_total + ($p->sale_price*$p->cnt);
                                    }?>

                                    </tbody>
                                </table>
                            </form>

                            <div class="cart-collaterals">
                            <div class="cart_totals" style="width:100%;">
                                <h2>Cart Totals</h2>
                                <input type="hidden" name="cart_total" id="cart_total" value="<?php echo $cart_total;?>">
                                <table cellspacing="0">
                                    <tbody>
                                        <tr class="cart-subtotal">
                                            <th style="width:200px;">구매 합계</th>
                                            <td><span class="amount" id="amount"><?php echo number_format($cart_total);?></span>원</td>
                                        </tr>
<?php
    if($_SESSION['UID']){
        $mymileage = my_mileage($_SESSION['UID']);
?>
                                        <tr class="order-total">
                                            <th style="width:200px;">마일리지</th>
                                            <td><input type="number" name="use_mileage" id="use_mileage" value="0" style="text-align:right;">원 [사용 가능 마일리지 : <?php echo number_format($mymileage);?>원]</td>
                                        </tr>
                                        <?php
                                        $q2 = "select ucid,coupon_name from user_coupons uc
                                        join coupons c on c.cid=uc.couponid
                                        where c.status = 2 and uc.status = 1 and uc.use_max_date >= now() and uc.userid='".$_SESSION['UID']."'";//사용 가능한 쿠폰을 확인
                                        $r2 = $mysqli->query($q2) or die("query error => ".$mysqli->error);
                                        while($cs2 = $r2->fetch_object()){
                                            $csa[]=$cs2;
                                        }
                                        ?>
                                        <input type="hidden" name="coupon_price" id="coupon_price" value="0">
                                        <tr class="shipping">
                                            <th style="width:200px;">쿠폰 선택</th>
                                            <td>
                                                <select name="coupon" id="coupon">
                                                    <option value="">선택하세요</option>
                                                    <?php
                                                        foreach ($csa as $c){
                                                    ?>
                                                        <option value="<?php echo $c->ucid;?>"><?php echo $c->coupon_name;?></option>
                                                    <?php }?>
                                                </select>
                                            </td>
                                        </tr>
<?php
}
$order_total = $cart_total - $use_mileage;
?>
                                        <tr class="order-total">
                                            <th style="width:200px;">주문 합계</th>
                                            <td><strong><span class="amount" id="total_amount"><?php echo number_format($order_total);?></span>원</strong> </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                            <input type="submit" value="주문하기" name="proceed" class="button">

                            </div>
                        </div>                        
                    </div>                    
                </div>
            </div>
        </div>
    </div>
   
<script>
    $('.remove').click(function(){
        var cid = $(this).attr("id");//cart 테이블 고유번호 cartid
        var qty = parseInt($("#qty_"+cid).val());//plus이므로 기존 값 가져와서 1을 더해줌
        var price = parseInt($("#price_"+cid).val());//제품마다 가격이 다르므로 가격 가져옴.
        var amount = parseInt($("#amount").text().replace(/,/gi, ""));//구매합계.
        var total_amount = parseInt($("#total_amount").text().replace(/,/gi, ""));//주문합계.

        if(!confirm('해당 상품을 삭제하시겠습니까?')){
            return false;
        }
       
        var data = {
            cid : cid
        };
            $.ajax({
                async : false,
                type : 'post' ,
                url : 'cart_del.php' ,
                data  : data ,
                dataType : 'json' ,//json으로 받음.
                error : function() {} ,
                success : function(return_data) {
                    if(return_data.result==true){
                        $("#cart_"+cid).remove();//해당 제품의 테이블의 tr값을 지운다.
                        $("#amount").text(number_format(amount-(price*qty)));//구매합계수정
                        $("#total_amount").text(number_format(total_amount-(price*qty)));//주문합계수정
                        $("#cart_total").val(total_amount-(price*qty));
                    }else{
                        alert('다시 시도해주십시오.');
                        return;
                    }
                }
        });
       
    });

    $('.plus').click(function(){
        var cid = $(this).attr("id");//cart 테이블 고유번호 cartid
        var qty = parseInt($("#qty_"+cid).val())+1;//plus이므로 기존 값 가져와서 1을 더해줌
        var price = parseInt($("#price_"+cid).val());//제품마다 가격이 다르므로 가격 가져옴.
        var amount = parseInt($("#amount").text().replace(/,/gi, ""));//구매합계.
        var total_amount = parseInt($("#total_amount").text().replace(/,/gi, ""));//주문합계.

        var data = {
            cid : cid,
            qty : qty,
            price : price
        };
            $.ajax({
                async : false,
                type : 'post' ,
                url : 'cart_edit.php' ,
                data  : data ,
                dataType : 'json' ,//json으로 받음.
                error : function() {} ,
                success : function(return_data) {
                    $("#amount_"+cid).text(number_format(return_data.amount)+"원");
                    $("#qty_"+cid).val(return_data.qty);
                    $("#amount").text(number_format(parseInt(return_data.price)+amount));//구매합계수정
                    $("#total_amount").text(number_format(parseInt(return_data.price)+total_amount));//주문합계수정
                    $("#cart_total").val(parseInt(return_data.price)+total_amount);
                }
        });
       
    });

    $('.minus').click(function(){
        var cid = $(this).attr("id");//cart 테이블 고유번호 cartid
        var qty = parseInt($("#qty_"+cid).val());//plus이므로 기존 값 가져옴

        if (qty > 1) { // 수량이 1보다 클 때만 감소
            qty = qty - 1; // 수량 감소
        
        
            var price = parseInt($("#price_"+cid).val());//제품마다 가격이 다르므로 가격 가져옴.
            var amount = parseInt($("#amount").text().replace(/,/gi, ""));//구매합계.
            var total_amount = parseInt($("#total_amount").text().replace(/,/gi, ""));//주문합계.

            var data = {
                cid : cid,
                qty : qty,
                price : price
            };

            $.ajax({
                async : false,
                type : 'post' ,
                url : 'cart_edit.php' ,
                data  : data ,
                dataType : 'json' ,//json으로 받음.
                error : function() {} ,
                success : function(return_data) {
                    $("#amount_"+cid).text(number_format(return_data.amount)+"원");
                    $("#qty_"+cid).val(return_data.qty);
                    $("#amount").text(number_format(amount-parseInt(return_data.price)));//구매합계수정
                    $("#total_amount").text(number_format(total_amount-parseInt(return_data.price)));//주문합계수정
                    $("#cart_total").val(total_amount-parseInt(return_data.price));
                }
            });
        }
       
    });

    $('#coupon').change(function(){
        var ucid = $("#coupon option:selected").val();//사용자 쿠폰 번호
        var cart_total = $("#cart_total").val();//구매 합계
        var data = {
            ucid : ucid,
            cart_total : cart_total
        };
            $.ajax({
                async : false,
                type : 'post' ,
                url : 'coupon_cal.ajax.php' ,
                data  : data ,
                dataType : 'json' ,//json으로 받음.
                error : function() {} ,
                success : function(return_data) {
                    if(return_data.result==false){
                        alert(return_data.msg);
                        $("#coupon").val('');
                        return false;
                    }else if(return_data.result==true){
                        $("#coupon_price").val(return_data.coupon_price);//coupon_price에 값을 넣어줌
                        var total_amount = parseInt($("#total_amount").text().replace(/,/gi, ""));//주문합계.
                        $("#total_amount").text(number_format(total_amount-parseInt(return_data.coupon_price)));//주문합계수정
                    }
                }
        });
    });

    $("#use_mileage").keyup(function() {
        var use_mileage = $("#use_mileage").val();
        var cart_total = $("#cart_total").val();
        var coupon_price = $("#coupon_price").val();
        var my_mileage = <?php echo $mymileage??0;?>;
        if(use_mileage>my_mileage){
            alert('사용가능한 마일리지를 초과하였습니다.');
            $("#use_mileage").val(0)
            $("#total_amount").text(number_format(cart_total));
            return false;
        }
        var ta = parseInt(cart_total) - parseInt(coupon_price) - parseInt(use_mileage);
        $("#total_amount").text(number_format(ta));
    });

    function number_format(num){
        return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g,',');
    }
</script>
<?php
include $_SERVER["DOCUMENT_ROOT"]."/inc/bot.php";
?>    