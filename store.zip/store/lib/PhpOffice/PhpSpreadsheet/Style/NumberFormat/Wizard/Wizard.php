<?php

namespace PhpOffice\PhpSpreadsheet\Style\NumberFormat\Wizard;

interface Wizard
{
    public function format(): string;
}
