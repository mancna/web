<?php
$_CONFIG["CDN_SERVER"] = "http://localhost";
$_CONFIG["LANGSET"] = $_COOKIE['lang_set']??"kr";

?>
