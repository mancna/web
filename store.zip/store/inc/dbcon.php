<?php
include $_SERVER["DOCUMENT_ROOT"]."/inc/config.php";
$hostname="localhost";
$dbuserid="root";
$dbpasswd="";
$dbname="testdb";

$mysqli = new mysqli($hostname, $dbuserid, $dbpasswd, $dbname);
if ($mysqli->connect_errno) {
    die('Connect Error: '.$mysqli->connect_error);
}

// Set the connection character set to utf8
if (!$mysqli->set_charset("utf8")) {
    die('Error loading character set utf8: '.$mysqli->error);
}

include $_SERVER["DOCUMENT_ROOT"]."/inc/lib.php";
?>
