<?php session_start();
include $_SERVER["DOCUMENT_ROOT"]."/inc/dbcon.php";
ini_set( 'display_errors', '0' );

$title = "Welcome"; // 기본 타이틀 설정

// 현재 페이지의 경로를 확인하여 타이틀 설정
$current_page = basename($_SERVER['PHP_SELF']);
if ($current_page === "index.php") { // 메인페이지
    $title = "쇼핑몰";
} elseif ($current_page === "index_board.php") { // 문의 게시판
    $title = "문의 게시판";
} elseif ($current_page === "login.php") { // 관리자-로그인
  $title = "관리자 로그인";
} elseif ($current_page === "product_list.php") { // 관리자-메인
  $title = "관리자 메인";
} elseif ($current_page === "product_up.php") { // 관리자-제품등록
  $title = "제품 등록";
} elseif ($current_page === "member_list.php") { // 관리자-회원관리
  $title = "회원 관리";
} elseif ($current_page === "category.php") { // 관리자-분류생성
  $title = "분류 생성";
} elseif ($current_page === "product_view.php") { // 관리자-보기
  $title = "제품 정보";
}

?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS --> 
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
  <script  src="http://code.jquery.com/jquery-latest.min.js"></script>
    <title><?php echo $title; ?></title> <!-- 동적으로 타이틀 설정 -->
  </head>
  <body>
  <div class="col-md-8" style="margin:auto;padding:20px;">