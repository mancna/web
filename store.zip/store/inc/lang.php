<?php

$_LANG['kr']['top']['myaccount'] = "내 계정";
$_LANG['en']['top']['myaccount'] = "My Account";
$_LANG['jp']['top']['myaccount'] = "アカウント";

$_LANG['kr']['top']['wishlist'] = "위시리스트";
$_LANG['en']['top']['wishlist'] = "Wish List";
$_LANG['jp']['top']['wishlist'] = "ウィッシュリスト";

$_LANG['kr']['top']['ask'] = "문의게시판";
$_LANG['en']['top']['ask'] = "Q & A Board";
$_LANG['jp']['top']['ask'] = "顧客掲示板";

$_LANG['kr']['top']['logout'] = "로그아웃";
$_LANG['en']['top']['logout'] = "Logout";
$_LANG['jp']['top']['logout'] = "ログアウト";

$_LANG['kr']['top']['mycart'] = "장바구니";
$_LANG['en']['top']['mycart'] = "My Cart";
$_LANG['jp']['top']['mycart'] = "カート";

$_LANG['kr']['top']['checkout'] = "체크아웃";
$_LANG['en']['top']['checkout'] = "Checkout";
$_LANG['jp']['top']['checkout'] = "チェックアウト";

$_LANG['kr']['top']['login'] = "로그인";
$_LANG['en']['top']['login'] = "Login";
$_LANG['jp']['top']['login'] = "ログイン";

$_LANG['kr']['top']['register'] = "회원가입";
$_LANG['en']['top']['register'] = "Signup";
$_LANG['jp']['top']['register'] = "会員登録";

$_LANG['kr']['top']['admin'] = "관리자모드";
$_LANG['en']['top']['admin'] = "Admin Mode";
$_LANG['jp']['top']['admin'] = "管理者モード";

$_LANG['kr']['top']['delcookie'] = "쿠키 삭제";
$_LANG['en']['top']['delcookie'] = "Delete Cookie";
$_LANG['jp']['top']['delcookie'] = "クッキーを削除";

$_LANG['kr']['top']['cart'] = "장바구니";
$_LANG['en']['top']['cart'] = "Shopping Cart";
$_LANG['jp']['top']['cart'] = "ショッピングカート";

?>