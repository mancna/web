<?php

function user_coupon($userid, $cid, $reason){
    global $mysqli;
    $query="select cid from coupons where cid=".$cid;
    $result = $mysqli->query($query) or die("query error => ".$mysqli->error);
    $rs = $result->fetch_object();

    if($rs->cid==1){//회원가입시 지급되는 쿠폰은 1회만 지급해야 하므로 지급한 내역이 있는지 확인
        $query2="select count(*) as cnt from user_coupons where couponid=".$rs->cid." and userid='".$userid."'";
        $result2 = $mysqli->query($query2) or die("query error => ".$mysqli->error);
        $rs2 = $result2->fetch_object();

        if(!$rs2->cnt){//이미 지급된 적이 없으면
            $last_date = date("Y-m-d 23:59:59", strtotime("+30 days")); //30일이 지나면 못쓴다.
            $sql="INSERT INTO user_coupons
            (couponid, userid, status, use_max_date, regdate, reason)
            VALUES(".$rs->cid.", '".$userid."', 1, '".$last_date."', now(), '".$reason."')";
            $ins=$mysqli->query($sql) or die($mysqli->error);
        }
    }else{
        if($rs->status==2){//실제 사용중인 쿠폰이면 쿠폰 발급
            $last_date = date("Y-m-d 23:59:59", strtotime("+30 days")); //30일이 지나면 못쓴다.
            $sql="INSERT INTO user_coupons
            (couponid, userid, status, use_max_date, regdate, reason)
            VALUES(".$rs->cid.", '".$userid."', 1, '".$last_date."', now(), '".$reason."')";
            $ins=$mysqli->query($sql) or die($mysqli->error);
        }
    }
}

function get_mileage($userid, $type){
    global $mysqli;
    $query="select * from mileage_type where tid=".$type;
    $result2 = $mysqli->query($query) or die("query error => ".$mysqli->error);
    $rs2 = $result2->fetch_object();
    $status = 1;
    $enddate = date("Y-m-d 23:59:59", strtotime("+{$rs2->period} days"));

    $sql="INSERT INTO `mileage_history`
    (`userid`,
    `mileage_plus`,
    `mileage_minus`,
    `type`,
    `status`,
    `startdate`,
    `enddate`)
    VALUES
    ('".$userid."',
    ".$rs2->mileage.",
    0,
    ".$type.",
    ".$status.",
    now(),
    '".$enddate."')";
    $ins=$mysqli->query($sql) or die($mysqli->error);

    $sql2 = "INSERT INTO `mileage`
    (`userid`,
    `mileage`)
    VALUES
    ('".$userid."',
    ".$rs2->mileage.") ON DUPLICATE KEY UPDATE mileage=mileage+".$rs2->mileage;// 없으면 입력하고 있으면 update 한다. 이때 가장 중요한것이 테이블을 만들때 기준이 되는 칼럼을 반드시 unique로 만들어야한다.
    $ins2=$mysqli->query($sql2) or die($mysqli->error);
}

function my_mileage($userid){
    global $mysqli;
    $query="SELECT sum(mileage_plus) - sum(mileage_minus) as mymileage
            FROM testdb.mileage_history
            where userid='".$userid."' and status=1    
            and date(startdate)<=date(now()) and date(enddate)>=date(now())";
    $result = $mysqli->query($query) or die("query error => ".$mysqli->error);
    $rs = $result->fetch_object();
    $mymileage = $rs->mymileage;

    $sql2 = "INSERT INTO `mileage`
    (`userid`,
    `mileage`)
    VALUES
    ('".$userid."',
    ".$mymileage.") ON DUPLICATE KEY UPDATE mileage=mileage+".$mymileage;
    $ins2=$mysqli->query($sql2) or die($mysqli->error);

    return $mymileage;
}

?>